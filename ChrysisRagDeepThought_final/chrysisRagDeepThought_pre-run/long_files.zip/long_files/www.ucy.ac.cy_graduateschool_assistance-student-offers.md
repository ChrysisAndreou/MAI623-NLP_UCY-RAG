# Assistance Student Offers

There are various sources of funding available at the University of Cyprus. Apart from scholarships offered by the State, the University of Cyprus may subsidize a postgraduate student who offers to work as an assistant in covering the needs of his/her department or other departments.

Assistantships may involve assisting in teaching, tutorials, help with assignments, lab supervision, grading, etc. They do not apply to the research activity of the student nor to the research activity of the academic and research staff. Monthly earnings can amount to Euro 342 or Euro 683 for a maximum period of ten months.

Interested students are invited to contact their Department for further information. Please note that, in case of interest, they must be active postgraduate students during the current academic year.