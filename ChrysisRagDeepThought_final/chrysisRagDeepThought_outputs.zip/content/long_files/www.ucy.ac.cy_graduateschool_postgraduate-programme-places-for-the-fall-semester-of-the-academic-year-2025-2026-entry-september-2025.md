# POSTGRADUATE PROGRAMME PLACES FOR THE FALL SEMESTER OF THE ACADEMIC YEAR 2025/2026 – ENTRY SEPTEMBER 2025

[###### REGISTRATION IN COURSES FOR THE SPRING SEMESTER 2024/2025

December 20, 2024](https://www.ucy.ac.cy/graduateschool/registration-in-courses-for-the-spring-semester-2024-2025/?lang=en)[###### SCHOLARSHIPS FOR SIBLINGS OR FIRST DEGREE RELATIVES OR MARRIED PARTNERS

February 17, 2025](https://www.ucy.ac.cy/graduateschool/scholarships-for-siblings-or-first-degree-relatives-or-married-partners-3/?lang=en)

[###### REGISTRATION IN COURSES FOR THE SPRING SEMESTER 2024/2025

December 20, 2024](https://www.ucy.ac.cy/graduateschool/registration-in-courses-for-the-spring-semester-2024-2025/?lang=en)[###### SCHOLARSHIPS FOR SIBLINGS OR FIRST DEGREE RELATIVES OR MARRIED PARTNERS

February 17, 2025](https://www.ucy.ac.cy/graduateschool/scholarships-for-siblings-or-first-degree-relatives-or-married-partners-3/?lang=en)

The University of Cyprus is accepting applications for the following postgraduate programmes for the academic year **2025-2026** with admission on **September 2025**.

Please, see the text of the announcement [**HERE**](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2025/02/Aggliki-Prokirixi-xeimerino-2025-2026.pdf).

Share

#### Related posts

April 16, 2025

#### [Department of Law – Postgraduate Programme Places for the Fall Semester of the Academic Year 2025/2026 – Entry September 2025](https://www.ucy.ac.cy/graduateschool/department-of-law-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/department-of-law-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

March 26, 2025

#### [EXTENSION OF APPLICATIONS FOR THE FALL SEMESTER 2025/2026](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/?lang=en)

March 6, 2025

#### [Department of Biological Sciences – Postgraduate Programme Places for the Fall Semester of the Academic Year 2025/2026 – Entry September 2025](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%b2%ce%b9%ce%bf%ce%bb%ce%bf%ce%b3%ce%b9%ce%ba%cf%8e%ce%bd-%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%cf%8e%ce%bd-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%b2%ce%b9%ce%bf%ce%bb%ce%bf%ce%b3%ce%b9%ce%ba%cf%8e%ce%bd-%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%cf%8e%ce%bd-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be/?lang=en)