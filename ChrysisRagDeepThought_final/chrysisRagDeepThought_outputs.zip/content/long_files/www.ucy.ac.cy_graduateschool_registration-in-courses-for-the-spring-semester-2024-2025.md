# REGISTRATION IN COURSES FOR THE SPRING SEMESTER 2024/2025

[###### 5th Interdisciplinary Forum – Call for proposals from Academic staff members and PhD students for thematic symposia and panels

October 23, 2024](https://www.ucy.ac.cy/graduateschool/5%ce%bf-%ce%b4%ce%b9%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%ce%bf%ce%bd%ce%b9%ce%ba%cf%8c-%cf%86%cf%8c%cf%81%ce%bf%cf%85%ce%bc-%cf%80%cf%81%cf%8c%cf%83%ce%ba%ce%bb%ce%b7%cf%83%ce%b7-%ce%b1%ce%ba/?lang=en)[###### POSTGRADUATE PROGRAMME PLACES FOR THE FALL SEMESTER OF THE ACADEMIC YEAR 2025/2026 – ENTRY SEPTEMBER 2025

February 5, 2025](https://www.ucy.ac.cy/graduateschool/postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

[###### 5th Interdisciplinary Forum – Call for proposals from Academic staff members and PhD students for thematic symposia and panels

October 23, 2024](https://www.ucy.ac.cy/graduateschool/5%ce%bf-%ce%b4%ce%b9%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%ce%bf%ce%bd%ce%b9%ce%ba%cf%8c-%cf%86%cf%8c%cf%81%ce%bf%cf%85%ce%bc-%cf%80%cf%81%cf%8c%cf%83%ce%ba%ce%bb%ce%b7%cf%83%ce%b7-%ce%b1%ce%ba/?lang=en)[###### POSTGRADUATE PROGRAMME PLACES FOR THE FALL SEMESTER OF THE ACADEMIC YEAR 2025/2026 – ENTRY SEPTEMBER 2025

February 5, 2025](https://www.ucy.ac.cy/graduateschool/postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

All postgraduate students of the University of Cyprus at Master and PhD Level, have to register electronically in their courses via [**BannerWeb System**](https://www.ucy.ac.cy/aasw/bannerweb/?lang=en) for the **Spring Semester 2024/2025.**  
  
The registration in courses will take place from **Wednesday 15th of January 2025 until Friday 24th of January 2025, from 09.30 a.m. to midnight.** For more information about courses registration please click [**here.**](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/12/Registrations-202501_eng-1.pdf)  
  
**Deadlines for Registration:**  
  
**Add a course:** Students can add a course from **Monday 20th of January 2025 until Friday 24th of January 2025 from 9.30 a.m. to midnight.**  
  
**Drop a course:** Students can drop a course **from Monday 3rd of February 2025 until Friday 7th of February 2025 from 9.30 a.m. to midnight.**  
  
**Withdrawal a course:** Students can leave a course **from the 10th of February 20245 until the 7th of March 2025.** This leaving is recorded in the student’s transcript as withdrawal. Students who choose to withdraw from a course should inform the Graduate School.

Share

#### Related posts

April 16, 2025

#### [Department of Law – Postgraduate Programme Places for the Fall Semester of the Academic Year 2025/2026 – Entry September 2025](https://www.ucy.ac.cy/graduateschool/department-of-law-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/department-of-law-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

March 26, 2025

#### [EXTENSION OF APPLICATIONS FOR THE FALL SEMESTER 2025/2026](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/?lang=en)

March 6, 2025

#### [Department of Biological Sciences – Postgraduate Programme Places for the Fall Semester of the Academic Year 2025/2026 – Entry September 2025](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%b2%ce%b9%ce%bf%ce%bb%ce%bf%ce%b3%ce%b9%ce%ba%cf%8e%ce%bd-%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%cf%8e%ce%bd-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%b2%ce%b9%ce%bf%ce%bb%ce%bf%ce%b3%ce%b9%ce%ba%cf%8e%ce%bd-%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%cf%8e%ce%bd-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be/?lang=en)