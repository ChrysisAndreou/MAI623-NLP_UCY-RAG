# UNIVERSITY CARD

[1) Self-Login procedure for acquiring your Employee Number and creating an account (23.11.2018)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/Self-Login-Procedure_23.11.2018.pdf)

[2) Instructions for Academic/Administrative staff for the issuance of the University Card (7.07.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/INSTRUCTIONS_FOR_ACADADMIN_STAFF_FOR_THE_ISSUANCE_OF_THE_UCYCARD_7.7.2022.pdf)

[3) Instructions for Students for the issuance of the University Card (7.07.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/INSTRUCTIONS_FOR_UNIVERSITY_STUDENTS_FOR_THE_ISSUANCE_OF_THE_UNIVERSITY_STUDENT_7.7.2022.pdf)

[4) Instructions for the Students of the school of Greek language for the issuance of the University Card (15.07.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/INSTRUCTIONS_FOR_THE_STUDENTS_OF_THE_SCHOOL_FOR_GREEK_LANGUAGE-ISSUANCE_OF_THE_U_CARD_15.7.22.pdf)

[5) Authorization given to another person for receiving your University card (19.07.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/Authorization_given_to_another_person_for_receiving_your_University_card_19.7.2022.pdf)

[6) Collection of the University cards, Days and Hours (7.07.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/Collection_of_the_University_card_Days_and_Hours_3.10.2022.pdf)

[7) Instructions in the case you have lost your University card (19.07.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/Lost_Card_19.7.2022_ENG.pdf)

[8) University Card - Student Rights (20/9/2018)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/Ucy_Card_Rights_20.9.2018.pdf)

[9) University Card - Staff Rights (20/9/2018)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/Ucy_Card_Staff_Rights_20.9.2018.pdf)

[10) Instructions for the electronic payment application of Ucy Card (19.7.2022)](https://www.ucy.ac.cy/expressservices2/wp-content/uploads/sites/151/2023/01/INSTRUCTIONS_FOR_THE_ELECTRONIC_PAYMENT_APPLICATION_OF_UCY_CARD_14.7.2021.pdf)