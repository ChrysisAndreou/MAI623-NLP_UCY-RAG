# Diploma Supplement

All the students of the University of Cyprus upon graduation on undergraduate and postgraduate level (Master’s degree) receive a copy of  
a Diploma Supplement automatically and free of charge. The Diploma Supplement-DS is a document attached to a higher education diploma aiming at improving international transparency  
and facilitating the academic and proffessional recognition of qualifications. The DS provides a standardised description of the nature, level, context, content and status of the studies completed by its holder.  
For further details please contact the Information Office of the Graduate School at: [[email protected]](/cdn-cgi/l/email-protection), or call at: +00357 22 894044.  
[Postgraduate Diploma Supplement](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2022/01/Diploma_Supplement.pdf)