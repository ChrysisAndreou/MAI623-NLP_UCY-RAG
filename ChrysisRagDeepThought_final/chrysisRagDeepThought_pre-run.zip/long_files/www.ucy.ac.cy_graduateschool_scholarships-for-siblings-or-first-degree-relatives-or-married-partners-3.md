# SCHOLARSHIPS FOR SIBLINGS OR FIRST DEGREE RELATIVES OR MARRIED PARTNERS

[###### POSTGRADUATE PROGRAMME PLACES FOR THE FALL SEMESTER OF THE ACADEMIC YEAR 2025/2026 – ENTRY SEPTEMBER 2025

February 5, 2025](https://www.ucy.ac.cy/graduateschool/postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)[###### ‘OPEN DAY Event of the Department of Social and Political Sciences’

March 5, 2025](https://www.ucy.ac.cy/graduateschool/open-day-event-of-the-department-of-social-and-political-sciences/?lang=en)

[###### POSTGRADUATE PROGRAMME PLACES FOR THE FALL SEMESTER OF THE ACADEMIC YEAR 2025/2026 – ENTRY SEPTEMBER 2025

February 5, 2025](https://www.ucy.ac.cy/graduateschool/postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)[###### ‘OPEN DAY Event of the Department of Social and Political Sciences’

March 5, 2025](https://www.ucy.ac.cy/graduateschool/open-day-event-of-the-department-of-social-and-political-sciences/?lang=en)

For more information you can find the latest announcement [here](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2025/02/Anakoinosi-Ekptosi-Syggenis-ΕΕ2024-2025-english-1.pdf).

Share

#### Related posts

April 16, 2025

#### [Department of Law – Postgraduate Programme Places for the Fall Semester of the Academic Year 2025/2026 – Entry September 2025](https://www.ucy.ac.cy/graduateschool/department-of-law-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/department-of-law-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)

March 26, 2025

#### [EXTENSION OF APPLICATIONS FOR THE FALL SEMESTER 2025/2026](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/?lang=en)

March 6, 2025

#### [Department of Biological Sciences – Postgraduate Programme Places for the Fall Semester of the Academic Year 2025/2026 – Entry September 2025](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%b2%ce%b9%ce%bf%ce%bb%ce%bf%ce%b3%ce%b9%ce%ba%cf%8e%ce%bd-%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%cf%8e%ce%bd-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be/?lang=en)

---

[Read more](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%b2%ce%b9%ce%bf%ce%bb%ce%bf%ce%b3%ce%b9%ce%ba%cf%8e%ce%bd-%ce%b5%cf%80%ce%b9%cf%83%cf%84%ce%b7%ce%bc%cf%8e%ce%bd-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be/?lang=en)