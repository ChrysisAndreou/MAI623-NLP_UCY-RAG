# Δραστηριότητες

Κάθε εξάμηνο το Γραφείο Στέγασης, σε συνεργασία με τους Βοηθούς Φοιτητικής Εστίας, διοργανώνει σειρά δραστηριοτήτων, εκδηλώσεων και εκπαιδεύσεων για τους ενοίκους, όπως μουσικές βραδιές, εκπαίδευση πρωτοετών σε θέματα χρήσης εξοπλισμού, συναντήσεις ενοίκων για γνωριμία, κλπ.

**Πρόγραμμα Εκδηλώσεων Χειμερινού Εξαμήνου 2022/23**

Welcome Party: Back to Dorms

Just Dance vs. Karaoke Night

Movie Night

**Πρόγραμμα Συναντήσεων Γνωριμίας Χειμερινού Εξαμήνου 2022/23**

**Πρόγραμμα Εκπαιδεύσεων  2022/23**

**Φωτογραφίες από προηγούμενες Δραστηριότητες**

#### Διεύθυνση

Πανεπιστήμιο Κύπρου  
Κτήριο Συμβουλίου-Συγκλήτου «Αναστάσιος Γ. Λεβέντης»  
Λεωφόρος Πανεπιστημίου 1, Αγλαντζιά  
2109 Αγλαντζιά  
Κύπρος

#### Ταχυδρομική Διεύθυνση

Πανεπιστήμιο Κύπρου  
Τ.Θ. 20537  
1678 Λευκωσία  
Κύπρος

#### Επικοινωνία

Πληροφορίες για Προπτυχιακές Σπουδές  
 : +357-22-894021  
 : [[email protected]](/cdn-cgi/l/email-protection)  
  
Πληροφορίες για Μεταπτυχιακές Σπουδές  
 : +357-22-894044  
 : [[email protected]](/cdn-cgi/l/email-protection)

[©  Πανεπιστήμιο Κύπρου](https://www.ucy.ac.cy). Με επιφύλαξη παντός δικαιώματος, όλα τα δικαιώματα προστατεύονται.

* [![EN](https://www.ucy.ac.cy/aasw/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.png)](https://www.ucy.ac.cy/aasw/student-welfare/housing-office/activities/?lang=en)
* [![EL](https://www.ucy.ac.cy/aasw/wp-content/plugins/sitepress-multilingual-cms/res/flags/el.png)](https://www.ucy.ac.cy/aasw/student-welfare/housing-office/activities/)