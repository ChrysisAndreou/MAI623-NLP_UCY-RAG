# ΚΕΝΤΡΟ ΠΛΗΡΟΦΟΡΗΣΗΣ - ΒΙΒΛΙΟΘΗΚΗ - «ΣΤΕΛΙΟΣ ΙΩΑΝΝΟΥ»

![](https://www.ucy.ac.cy/wp-content/uploads/2022/10/banner9.webp)

# ΠΟΛΙΤΙΣΤΙΚΟ ΚΕΝΤΡΟ «ΜΙΧΑΛΗΣ ΠΙΕΡΗΣ»

[![image2418](https://www.ucy.ac.cy/wp-content/uploads/2021/11/image2418.jpg)

#### ΕΡΕΥΝΑ](https://www.ucy.ac.cy/research/el/)

[![image2438](https://www.ucy.ac.cy/wp-content/uploads/2021/11/image2438.jpg)

#### ΠΟΛΙΤΙΣΜΟΣ](https://www.ucy.ac.cy/wp-content/uploads/2024/08/ΠΡΟΓΡΑΜΜΑ-SEP-OCT-2024.pdf)

[![home_university_tabber_3](https://www.ucy.ac.cy/wp-content/uploads/2022/05/home_university_tabber_3-e1653029484909.jpg)

#### ΣΧΟΛΕΣ ΚΑΙ ΤΜΗΜΑΤΑ](https://www.ucy.ac.cy/about/administration/faculties-and-departments/?lang=el)

[![image3005](https://www.ucy.ac.cy/wp-content/uploads/2021/11/image3005-1.jpg)

#### ΘΕΣΕΙΣ ΕΡΓΑΣΙΑΣ](https://www.ucy.ac.cy/hr/employment/vacancies/)

[#### ΠΡΟΠΤΥΧΙΑΚΕΣ ΣΠΟΥΔΕΣ](https://www.ucy.ac.cy/aasw/studies/undergraduate-studies/?lang=el)

[#### ΜΕΤΑΠΤΥΧΙΑΚΕΣ ΣΠΟΥΔΕΣ](https://www.ucy.ac.cy/graduateschool/?lang=el)

[#### ΔΙΕΘΝΕΙΣ ΦΟΙΤΗΤΕΣ/ΤΡΙΕΣ](https://www.ucy.ac.cy/internationalsupport/)

[#### ΣΤΑΔΙΟΔΡΟΜΙΑ](https://www.ucy.ac.cy/careercentre)

[#### ΑΠΟΦΟΙΤΕΣ/ΟΙ](https://www.ucy.ac.cy/alumni/el/)

[#### ΚΙΝΗΤΙΚΟΤΗΤΑ](https://www.ucy.ac.cy/ir/mobility/erasmus/general-information-erasmus/)

# ΓΝΩΣΗ, ΕΡΕΥΝΑ, ΚΑΙΝΟΤΟΜΙΑ

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/ema_gr.png)](https://www.ucy.ac.cy/aru/el/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/koe_gr.png)](https://www.ucy.ac.cy/erc/el/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/emphasis_eng.png)](http://www.emphasis.ucy.ac.cy/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/09/kios.png)](http://www.kios.ucy.ac.cy)

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/biobank-1.png)](https://biobank.cy/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/ocean_gr.png)](https://www.ucy.ac.cy/oceanography/el/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/nireas.png)](https://www.nireas-iwrc.org/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/can_gr.png)](https://www.cancyprus.org/)

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/08/cemar1000x320.png)](https://www.ucy.ac.cy/cemar/?lang=el)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/foss.png)](https://fosscy.eu/)[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/berc_gr.png)](http://www.eng.ucy.ac.cy/biomed/GR/)

[![](https://www.ucy.ac.cy/wp-content/uploads/2024/01/PHAETHON.png)](https://fosscy.eu/)

# ΝΕΑ ΚΑΙ ΕΚΔΗΛΩΣΕΙΣ

* Filter by
* [Categories](#)
* [Tags](#)
* [Authors](#)

* [Όλα](https://www.ucy.ac.cy/)
* [Εκδηλώσεις](https://www.ucy.ac.cy/blog/category/eventsgr/)
* [Νέα](https://www.ucy.ac.cy/blog/category/newsgr/)

* [Όλα](https://www.ucy.ac.cy/)

* [Όλα](https://www.ucy.ac.cy/)
* [popi](https://www.ucy.ac.cy/blog/author/popi/)

02/05/2025

[![](https://www.ucy.ac.cy/wp-content/uploads/2025/05/Σταύρος-Ζένιος-2-2-340x270.jpg)](https://www.ucy.ac.cy/blog/zenios/)

02/05/2025

##### [Διεθνής επιστημονική διάκριση για τον Καθηγητή Σταύρο Ζένιο με την εκλογή του στην Academia Europaea – Ακαδημία της Ευρώπης](https://www.ucy.ac.cy/blog/zenios/)

Την εξαιρετικά τιμητική διάκριση της εκλογής του ως Μέλους […]

30/04/2025

[![](https://www.ucy.ac.cy/wp-content/uploads/2025/04/EUSOME-website-large-drone-480x270.jpg)](https://www.ucy.ac.cy/blog/eusome-excellence-hub-%ce%b5%ce%ba%cf%83%cf%85%ce%b3%cf%87%cf%81%ce%bf%ce%bd%ce%b9%cf%83%ce%bc%cf%8c%cf%82-%cf%84%ce%bf%cf%85-%ce%bf%ce%b9%ce%ba%ce%bf%cf%83%cf%85%cf%83%cf%84%ce%ae%ce%bc%ce%b1%cf%84/)

30/04/2025

##### [EUSOME Excellence Hub: Εκσυγχρονισμός του Οικοσυστήματος Προηγμένης Εναέριας Κινητικότητας στη Νοτιοανατολική Μεσόγειο](https://www.ucy.ac.cy/blog/eusome-excellence-hub-%ce%b5%ce%ba%cf%83%cf%85%ce%b3%cf%87%cf%81%ce%bf%ce%bd%ce%b9%cf%83%ce%bc%cf%8c%cf%82-%cf%84%ce%bf%cf%85-%ce%bf%ce%b9%ce%ba%ce%bf%cf%83%cf%85%cf%83%cf%84%ce%ae%ce%bc%ce%b1%cf%84/)

Έναρξη του καινοτόμου έργου EUSOME που θα εκσυγχρονίσει το οικοσύστημα […]

11/04/2025

[![](https://www.ucy.ac.cy/wp-content/uploads/2025/04/UCY-panoram-2025-480x270.jpg)](https://www.ucy.ac.cy/blog/green/)

11/04/2025

##### [Προς μια Πράσινη και Βιώσιμη Πανεπιστημιούπολη: Υπογραφή Σύμβασης για εκπόνηση Υδρολογικής και Υδραυλικής Μελέτης στην Πανεπιστημιούπολη στην Αθαλάσσα](https://www.ucy.ac.cy/blog/green/)

Στρατηγική συνεργασία με τεχνικούς φορείς για την αντιπλημμυρική θωράκιση και […]

10/04/2025

[![](https://www.ucy.ac.cy/wp-content/uploads/2025/03/Banner_Ocean2024_620x400-480x270.jpg)](https://www.ucy.ac.cy/blog/%ce%b3%ce%b9%ce%bd%cf%8c%ce%bc%ce%b1%cf%83%cf%84%ce%b5-%ce%b8%ce%b1%ce%bb%ce%ac%cf%83%cf%83%ce%b9%ce%bf%ce%b9-%ce%b5%cf%81%ce%b5%cf%85%ce%bd%ce%b7%cf%84%ce%ad%cf%82-%ce%ba/)

10/04/2025

##### [«Γινόμαστε ‘θαλάσσιοι ερευνητές’ και ανακαλύπτουμε τα μυστικά του ωκεανού στο Ωκεανογραφικό Κέντρο ΠΚ – Δράση για απόφοιτες/τους 3/5/2025](https://www.ucy.ac.cy/blog/%ce%b3%ce%b9%ce%bd%cf%8c%ce%bc%ce%b1%cf%83%cf%84%ce%b5-%ce%b8%ce%b1%ce%bb%ce%ac%cf%83%cf%83%ce%b9%ce%bf%ce%b9-%ce%b5%cf%81%ce%b5%cf%85%ce%bd%ce%b7%cf%84%ce%ad%cf%82-%ce%ba/)

Ελάτε να ζήσετε μια μοναδική εκπαιδευτική και ψυχαγωγική εμπειρία που […]

17/05/2022

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/05/0862_UCY_FUNDRAISING_CAMPAIGN_POST_620x400_GR-480x270.png)](https://www.ucy.ac.cy/blog/ucy-giving-back-invest-in-knowledge/)

17/05/2022

##### [Εκστρατεία του ΠΚ «Giving Back» για την οικονομική ενίσχυση των φοιτητών/τριων](https://www.ucy.ac.cy/blog/ucy-giving-back-invest-in-knowledge/)

Αναπόσπαστο κομμάτι της αποστολής του Πανεπιστημίου Κύπρου και ταυτόχρονα μία […]

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/09/UCY_DiaViou_15x11_Orange_GR-300x220.jpg)](https://www.ucy.ac.cy/services/life-long-learning/?lang=el)

Διά Βίου Μάθηση

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/11/UCY_PodcastAllScience_2022_hi-1000-x-752-300x226.jpg)](https://www.ucy.ac.cy/services/science-talks/?lang=el)

Science Talks

[![](https://www.ucy.ac.cy/wp-content/uploads/2024/11/UCYKatataxeis11.24.gif)](https://www.ucy.ac.cy/uds/rankings/)

Διεθνείς Κατατάξεις

[![](https://www.ucy.ac.cy/wp-content/uploads/2023/05/YouTube_1772x1299_Research-300x220.jpg)](https://www.ucy.ac.cy/ucy_research/?lang=el)

H έρευνα στο Πανεπιστήμιο Κύπρου

[![](https://www.ucy.ac.cy/wp-content/uploads/2023/05/YouTube_1772x1299_Books-300x220.jpg)](https://www.ucy.ac.cy/scientific_publications/?lang=el)

Επιστημονικές και άλλες εκδόσεις

##### Συνδεθείτε μαζί μας

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/yufe-250-x-250.png)](https://yufe.eu)

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/yerun250x250-1.png)](https://yerun.eu/)

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/eures-250-x-250_transparent.png)](https://ec.europa.eu/eures/public/index_el)

[![](https://www.ucy.ac.cy/wp-content/uploads/2022/07/hr_transparent_resize.png)](https://euraxess.ec.europa.eu/jobs/hrs4r/awarded)

#### ΕΠΙΚΟΙΝΩΝΙΑ

**Πανεπιστήμιο Κύπρου**  
Κτήριο Συμβουλίου-Συγκλήτου «Αναστάσιος Γ. Λεβέντης»  
Λεωφ. Πανεπιστημίου 1  
2109 Αγλαντζιά, Λευκωσία  
Τ.Θ. 20537, 1678 Λευκωσία, Κύπρος

: [[email protected]](/cdn-cgi/l/email-protection#1c75727a735c697f65327d7f327f65)  
 : +357-22-894000  
[Επεξεργασία Δεδομένων Τηλεφωνικού Κέντρου](https://www.ucy.ac.cy/wp-content/uploads/2022/09/Data-Processing-Policy-For-UCY-Telephone-Center_GR.pdf)

#### ΠΛΗΡΟΦΟΡΙΕΣ ΠΡΟΣ

* [Υποψήφιους/ες Φοιτητές/τριες](https://www.ucy.ac.cy/prospective-students/?lang=el)
* [Υφιστάμενους/ες Φοιτητές/τριες](https://www.ucy.ac.cy/current-students/?lang=el)
* [Φοιτητές/τριες Εξωτερικού](https://www.ucy.ac.cy/internationalsupport/)
* [Απόφοιτους](https://www.ucy.ac.cy/alumni-development/)/ες
* [ΜΜΕ](https://www.ucy.ac.cy/information-for-media/?lang=el)
* [Επισκέπτες/τριες](https://www.ucy.ac.cy/livinginnicosia)

#### ΠΛΗΡΟΦΟΡΙΕΣ ΓΙΑ

* [Οργανωμένες Οντότητες](https://www.ucy.ac.cy/about/administration/university-resources/?lang=el)
* [Γραφείο Ταχείας Εξυπηρέτησης](https://www.ucy.ac.cy/expressservices/)
* [Ενοικιάσεις Χώρων](https://www.ucy.ac.cy/commercialservices)
* [Προσφορές](https://www.ucy.ac.cy/procurement/)
* [Αναμνηστικά Είδη](https://eshop.ucy.ac.cy/?lang=el)
* [Σχέδιο Δημοσίευσης Πληροφοριών ΠΚ](https://www.ucy.ac.cy/wp-content/uploads/2022/07/Sxedio-Dimosiefsis_Ν_184Ι-2017_Epitropo-Plir_UCY_14-07-2020_GR.pdf)
* [Πολιτική Προστασίας Προσωπικών Δεδομένων του Πανεπιστημίου Κύπρου](https://www.ucy.ac.cy/legislation/wp-content/uploads/KD-7-1.pdf)
* [Διαδρομές Λεωφορείων](https://www.ucy.ac.cy/hr/bus-routes/)

#### ΠΗΓΕΣ

* [Βιβλιοθήκη](https://library.ucy.ac.cy)
* [Αθλητισμός](https://www.ucy.ac.cy/athletics/index.php/el/)
* [Πολιτιστικό Κέντρο «Μιχάλης Πιερής»](https://www.ucy.ac.cy/cucentre/index.php/el/)
* [Δημόσιες Σχέσεις](https://www.ucy.ac.cy/pr/el/)
* [Ραδιοφωνικός Σταθμός](https://www.ucy.ac.cy/ucyvoice/)
* [Εκδόσεις](https://www.ucy.ac.cy/publications)
* [Πανεπιστημιακές Εκδόσεις Κύπρου](https://www.ucy.ac.cy/paneky/)
* [ΠΚ και Περιβάλλον](http://www.ucy.ac.cy/environment)
* [Ακαδημαϊκό Ημερολόγιο](https://www.ucy.ac.cy/aasw/academic-calendar)

#### ΕΡΓΑΛΕΙΑ

* [Θεματικός Κατάλογος Α-Ω](https://www.ucy.ac.cy/about/contact-us/university-a-z/?lang=el)
* [Κατάλογος Προσωπικού](https://www.ucy.ac.cy/directory/el)
* [Ημερολόγιο Εκδηλώσεων](http://applications.ucy.ac.cy/public/events/displayCalendar_allusers)
* [Κατάλογος Εμπειρογνωμόνων](https://www.ucy.ac.cy/pr/ucy-experts/)
* [BannerWeb](https://www.ucy.ac.cy/aasw/bannerweb/?lang=el)
* [Χάρτες](https://www.ucy.ac.cy/ts/ucy-map/)
* [Γκαλερί Φωτογραφιών](https://www.ucy.ac.cy/ucy-photos/)
* [Υπηρεσίες Διαδικτύου](https://www.ucy.ac.cy/web-applications/?lang=el)
* [Διαδικτυακή Πύλη ΠΚ](https://my.ucy.ac.cy)
* [Ηλ.Ταχυδρομείο](https://www.office.com)

[©  Πανεπιστήμιο Κύπρου](https://www.ucy.ac.cy/el). Με επιφύλαξη παντός δικαιώματος, όλα τα δικαιώματα προστατεύονται.

Ο παρών ιστότοπος χρησιμοποιεί cookies που βοηθούν τη λειτουργία του και παρακολουθούν τον τρόπο με τον οποίο αλληλεπιδράτε με αυτόν, ώστε να σας παρέχουμε μια βελτιωμένη και προσαρμοσμένη εμπειρία χρήστη. Θα χρησιμοποιήσουμε τα cookies μόνο εάν συναινέσετε στη χρήση τους κάνοντας κλικ στο κουμπί "Αποδοχή όλων". Διαβάστε περισσότερα στην ["Πολιτική Απορρήτου Cookies"](https://www.ucy.ac.cy/media/about/data-protection/University%20of%20Cyprus%20-%20Website%20and%20Cookie%20Privacy%20Policy.pdf).

![UCY Logo](https://www.ucy.ac.cy/chem/wp-content/uploads/sites/12/2021/04/android-icon-36x36-5.png)ΠΡΟΤΙΜΗΣΕΙΣΑΚΥΡΩΣΗΑΠΟΔΟΧΗ ΟΛΩΝ

Διαχείριση συναίνεσης

Close

#### Επισκόπηση απορρήτου

Αυτός ο ιστότοπος χρησιμοποιεί cookies για να βελτιώσει την εμπειρία σας κατά την πλοήγηση στον ιστότοπο. Από αυτά, τα cookies που κατηγοριοποιούνται ως απαραίτητα αποθηκεύονται στο πρόγραμμα περιήγησής σας καθώς είναι απαραίτητα για τη λειτουργία των βασικών λειτουργιών του ιστότοπου. Χρησιμοποιούμε επίσης cookies τρίτων που μας βοηθούν να αναλύσουμε και να κατανοήσουμε πώς χρησιμοποιείτε αυτόν τον ιστότοπο. Αυτά τα cookies θα αποθηκευτούν στο πρόγραμμα περιήγησής σας μόνο με τη συγκατάθεσή σας. Έχετε επίσης την επιλογή να εξαιρεθείτε από αυτά τα cookies. Ωστόσο, η εξαίρεση από ορισμένα από αυτά τα cookies μπορεί να επηρεάσει την εμπειρία περιήγησής σας. Για επιλογή των κατηγοριών Cookies, μπορείτε να επισκεφθείτε την αγγλική ιστοσελίδα και να επιλέξετε το κουμπί "Cookie Settings".

SAVE & ACCEPT

Powered by [![CookieYes Logo](https://www.ucy.ac.cy/wp-content/plugins/cookie-law-info/legacy/public/images/logo-cookieyes.svg)](https://www.cookieyes.com/)

Please ensure Javascript is enabled for purposes of [website accessibility](https://userway.org)

X

* ←
* Βοηθήστε μας για βελτίωση

  Βοηθήστε μας να βελτιώσουμε την ιστοσελίδα μας

  Όνομα (προαιρετικό)

  Η-ταχυδρομέιο (προαιρετικό)

  Οι εισηγήσεις και τα σχόλια σας είναι σημαντικά για μας για βελτίωση