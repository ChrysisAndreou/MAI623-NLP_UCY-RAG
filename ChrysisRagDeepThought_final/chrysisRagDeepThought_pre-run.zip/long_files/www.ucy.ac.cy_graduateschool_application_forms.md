# Applications / Forms

* [Special Permission For Enrolment in More than 30 ECTS](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/05/entypo-gia-eggrafi-se-peran-ton-45-english.docx)
* [Student Declaration Full Scholarship to PhD Students](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2022/01/ypotrofies_ipefthini_dilosi_se_PhD_english_12.10.21.pdf)
* [External Attendant (Audit Students Form)](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/07/EXTERNAL_ATTENDANT_AUDIT_STUDENTS_FORM.docx)
* [Scholarships to Postgraduate Students for Partial Tuition Coverage](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2025/02/scholarships_discount_english.docx) [(SCHOLARSHIPS FOR SIBLINGS OR FIRST DEGREE RELATIVES OR MARRIED PARTNERS)](https://www.ucy.ac.cy/graduateschool/scholarships/?lang=en)
* [Recommendation Letter Form for Admission to the Graduate Programmes of the Faculty of Engineering](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2022/01/recommendationLetterEN_Politechnikis.doc)
* [Recommendation Letter Form for Admission to the Graduate Programmes of the Department of Psychology](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2025/03/Recommendation_Form_-_English-1.doc)
* [Conference/Lecture Attendance Form](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/05/CONFERENCE_LECTURE_ATTENDANCE_FORM_EN.doc)
* [Recommendation Letter Form](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/02/Έντυπο-Συστατικής-Επιστολής-ΣΜΣ-Πανεπιστήμιο-Κύπρου.docx)
* [Submission Form of Supporting Documents for the Award of a PhD Degree](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/05/Phd-degree-award-sumbission-form-eng.doc)
* [Change in Grade Form](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/05/Entypo-Allagis-Bathmologias-english.docx)
* [Descriptions and Approvals of New Courses (Forms for the approval of new courses in the Department’s Curricula (undergraduate and postgraduate) and for the preparation of diagrams for the courses offered during the semester (to the extent applicable)](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/05/CourseDescription_EN.docx).
* [Form for Registration in Courses (Students from Gaza)](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2024/07/registrationformTESI.docx).

The forms for use by the academic community located on the [Portal of the University of Cyprus](https://my.ucy.ac.cy/apps/eservices/r/portal/forms?session=16725908200224) (controlled access).