# Forms

[MEDU1/MEDUM1](https://www.ucy.ac.cy/internationalsupport/wp-content/uploads/sites/117/2023/06/FORM-MEDUMEDUM1-FINAL-4.docx) (Application for the grant of the **Entry Permit Visa** to an alien to enter Cyprus – **fill in only your personal details in Part I – page 2)**

[MEDU1/MEDUM1](https://www.ucy.ac.cy/internationalsupport/wp-content/uploads/sites/117/2023/06/FORM-MEDUMEDUM1-FINAL-4.docx) (Application for the grant of the**Temporary Resident’s Permit** – **fill in only your personal details in Part I – page 2 and sign at PART IV – page 3**the last part where it says “Official Declaration of the Third Country National”).

[MEDU1/MEDUM1](https://www.ucy.ac.cy/internationalsupport/wp-content/uploads/sites/117/2023/06/FORM-MEDUMEDUM1-FINAL-4.docx) (Application for the **Renewal of the Temporary Resident’s Permit** – **fill in only your personal details in Part I – page 2 and sign at PART IV – page 3**the last part where it says “Official Declaration of the Third Country National”).

[MGEN2](https://www.ucy.ac.cy/irs/wp-content/uploads/sites/115/2022/10/MGEN2.pdf) (Application for the acquisition of Entry Permit, Registration and the acquisition / Renewal of a temporary residence permit for purposes of remunerated employment)

[Hosting Agreement](https://www.ucy.ac.cy/internationalsupport/wp-content/uploads/sites/117/2022/03/HostingAgreementUCY-ResearcherCitizen3rdCountry.doc) (Agreement between Approved Cypriot Research Organization and Researcher Citizen of Third Country)

*[Student’s Declaration](https://www.ucy.ac.cy/internationalsupport/wp-content/uploads/sites/117/2022/03/DECLARATION_for_ASYLUM-1.docx) (for not granting an Asylum)*

[MEU1](https://www.ucy.ac.cy/irs/wp-content/uploads/sites/115/2022/10/Form-MEU1-EU-Citizens.pdf) (Application for issue of registration certificate of Union Citizen and his/her family members also EU Citizens)

[MFR1](https://www.ucy.ac.cy/internationalsupport/wp-content/uploads/sites/117/2023/06/Αίτηση-Form-MFR1.pdf) (Application for Family Reunification)