# Δημιουργική Μάθηση και Τέχνες στην Παιδική Ηλικία – Εξ Αποστάσεως

#### Επικοινωνία

**Τα Γραφεία μας**  
**Τμήμα Επιστημών της Αγωγής**  
Κτήριο The Crosspoint  
Γωνιά Καλλιπόλεως και Υπατίας 1  
1071 Λευκωσία  
  
**Πανεπιστήμιο Κύπρου**  
P.O. Box 20537  
CY-1678 Λευκωσία  
Κύπρος  
  
**Διοικητικό Προσωπικό**  
  
**Χριστίνα Γεωργίου Μιχαηλίδη**  
 : +357-22-892941  
 : [[email protected]](/cdn-cgi/l/email-protection)   
  
**Αναστασία Κώστα Δημητρίου**  
 : +357-22-892942  
 : [[email protected]](/cdn-cgi/l/email-protection)   
  
**Πόπη Κίτσιου**  
 : +357-22-892940  
 : [[email protected]](/cdn-cgi/l/email-protection)

#### Τελευταία Νέα

* [![](https://www.ucy.ac.cy/edu/wp-content/uploads/sites/23/2025/04/919474-large_thumbnail-150x150.webp)0

  ###### «Η αναπηρία να μην αντιμετωπίζεται με οίκτο»: Η Μάρω Καΐμη, φοιτήτρια του ΠΚ δίνει τα δικά της μηνύματα παρά τις δυσκολίες κινητικότητας

  29 Απριλίου, 2025](https://www.politis.com.cy/politis-news/koinonia/919474/-i-anapiria-na-min-antimetopizetai-me-oikto-i-maro-kaimi-foititria-toy-pk-dinei-ta-dika-tis-minymata-para-tis-dyskolies-kinitikotitas?fbclid=IwY2xjawJNUohleHRuA2FlbQIxMQABHeeSQyAzHFMOdPHTCGJRmH3HMOcrKE0SO4-2FClhcVx4t3BBXDgCzNJ6Sg_aem_IMTgbm3nV8aKWDsi4K5MDg#new_tab)
* [0

  ###### Το Τμήμα Επιστημών της Αγωγής του Πανεπιστημίου Κύπρου δέχεται αιτήσεις για την πλήρωση θέσεων Ειδικών Επιστημόνων Διδασκαλίας για εποπτεία στη Σχολική Εμπειρία (Πρακτική Άσκηση) στο γνωστικό αντικείμενο Ιστορία στο Δημοτικό Σχολείο, μέχρι και την Παρασκευή 11 Απριλίου 2025.

  28 Μαρτίου, 2025](https://www.ucy.ac.cy/hr/wp-content/uploads/sites/253/2025/03/%CE%A3%CF%87%CE%BF%CE%BB%CE%B9%CE%BA%CE%AE-%CE%95%CE%BC%CF%80%CE%B5%CE%B9%CF%81%CE%AF%CE%B1-%CE%B9%CF%83%CF%84%CE%BF%CF%81%CE%AF%CE%B1.pdf#new_tab)

#### Εγγραφείτε εδώ !

Όνομα και Επίθετο

Ηλεκτρονικό Ταχυδρομείο

[Αποδοχή Πολιτικής Προστασίας Προσωπικών Δεδομένων του Πανεπιστήμιου Κύπρου](https://www.ucy.ac.cy/legislation/wp-content/uploads/KD-7.pdf)

#### Ημερολόγιο

Μάιος 2025

| Δ | Τ | Τ | Π | Π | Σ | Κ |
| --- | --- | --- | --- | --- | --- | --- |
|  | | | 1 | 2 | 3 | 4 |
| 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| 12 | 13 | 14 | 15 | 16 | 17 | 18 |
| 19 | 20 | 21 | 22 | 23 | 24 | 25 |
| 26 | 27 | 28 | 29 | 30 | 31 |  |

[« Απρ](https://www.ucy.ac.cy/edu/2025/04/)

[©  Πανεπιστήμιο Κύπρου](https://www.ucy.ac.cy/el). Με επιφύλαξη παντός δικαιώματος, όλα τα δικαιώματα προστατεύονται.

* [No translations available for this page](#)

##### Πανεπιστήμιο Κύπρου - Συναίνεση cookie

Ο παρών ιστότοπος χρησιμοποιεί cookies που βοηθούν τη λειτουργία του και παρακολουθούν τον τρόπο με τον οποίο αλληλεπιδράτε με αυτόν, ώστε να σας παρέχουμε μια βελτιωμένη και προσαρμοσμένη εμπειρία χρήστη. Θα χρησιμοποιήσουμε τα cookies μόνο εάν συναινέσετε στη χρήση τους κάνοντας κλικ στο κουμπί "Αποδοχή όλων". Διαβάστε περισσότερα στην"Πολιτική Απορρήτου Cookies" [Πολιτική Απορρήτου Ιστοσελίδας και Cookie - Γραφείο Προστασίας Δεδομένων](https://www.ucy.ac.cy/media/about/data-protection/University%20of%20Cyprus%20-%20Website%20and%20Cookie%20Privacy%20Policy.pdf).

![](https://www.ucy.ac.cy/chem/wp-content/uploads/sites/12/2021/04/android-icon-36x36-5.png)ΠροτιμήσειςΑΠΟΡΡΙΨΗ ΟΛΩΝΑΠΟΔΟΧΗ ΟΛΩΝ

Manage consent

Close