# ΠΡΟΚΗΡΥΞΗ ΘΕΣΕΩΝ ΜΕΤΑΠΤΥΧΙΑΚΩΝ ΠΡΟΓΡΑΜΜΑΤΩΝ ΓΙΑ ΤΟ ΧΕΙΜΕΡΙΝΟ ΕΞΑΜΗΝΟ ΤΟΥ ΑΚΑΔΗΜΑΪΚΟΥ ΕΤΟΥΣ 2025/2026 – ΕΙΣΔΟΧΗ ΣΕΠΤΕΜΒΡΙΟΣ 2025

[###### ΕΓΓΡΑΦΕΣ ΕΑΡΙΝΟΥ ΕΞΑΜΗΝΟΥ 2024/2025

20 Δεκεμβρίου, 2024](https://www.ucy.ac.cy/graduateschool/%ce%b5%ce%b3%ce%b3%cf%81%ce%b1%cf%86%ce%b5%cf%83-%ce%b5%ce%b1%cf%81%ce%b9%ce%bd%ce%bf%cf%85-%ce%b5%ce%be%ce%b1%ce%bc%ce%b7%ce%bd%ce%bf%cf%85-2024-2025/)[###### ΥΠΟΤΡΟΦΙΕΣ ΣΕ ΜΕΤΑΠΤΥΧΙΑΚΟΥΣ/ΕΣ ΦΟΙΤΗΤΕΣ/ΤΡΙΕΣ ΤΟΥ ΠΑΝΕΠΙΣΤΗΜΙΟΥ ΚΥΠΡΟΥ (αδέρφια ή συγγενείς πρώτου βαθμού ή ζευγάρια)

17 Φεβρουαρίου, 2025](https://www.ucy.ac.cy/graduateschool/%cf%85%cf%80%ce%bf%cf%84%cf%81%ce%bf%cf%86%ce%b9%ce%b5%cf%83-%cf%83%ce%b5-%ce%bc%ce%b5%cf%84%ce%b1%cf%80%cf%84%cf%85%cf%87%ce%b9%ce%b1%ce%ba%ce%bf%cf%85%cf%83-%ce%b5%cf%83-%cf%86%ce%bf%ce%b9%cf%84-2/)

[###### ΕΓΓΡΑΦΕΣ ΕΑΡΙΝΟΥ ΕΞΑΜΗΝΟΥ 2024/2025

20 Δεκεμβρίου, 2024](https://www.ucy.ac.cy/graduateschool/%ce%b5%ce%b3%ce%b3%cf%81%ce%b1%cf%86%ce%b5%cf%83-%ce%b5%ce%b1%cf%81%ce%b9%ce%bd%ce%bf%cf%85-%ce%b5%ce%be%ce%b1%ce%bc%ce%b7%ce%bd%ce%bf%cf%85-2024-2025/)[###### ΥΠΟΤΡΟΦΙΕΣ ΣΕ ΜΕΤΑΠΤΥΧΙΑΚΟΥΣ/ΕΣ ΦΟΙΤΗΤΕΣ/ΤΡΙΕΣ ΤΟΥ ΠΑΝΕΠΙΣΤΗΜΙΟΥ ΚΥΠΡΟΥ (αδέρφια ή συγγενείς πρώτου βαθμού ή ζευγάρια)

17 Φεβρουαρίου, 2025](https://www.ucy.ac.cy/graduateschool/%cf%85%cf%80%ce%bf%cf%84%cf%81%ce%bf%cf%86%ce%b9%ce%b5%cf%83-%cf%83%ce%b5-%ce%bc%ce%b5%cf%84%ce%b1%cf%80%cf%84%cf%85%cf%87%ce%b9%ce%b1%ce%ba%ce%bf%cf%85%cf%83-%ce%b5%cf%83-%cf%86%ce%bf%ce%b9%cf%84-2/)

Το Πανεπιστήμιο Κύπρου ανακοινώνει την προκήρυξη των θέσεων για τα μεταπτυχιακά προγράμματα Μάστερ και Διδακτορικού επιπέδου για το ακαδημαϊκό έτος **2025-2026** με εισδοχή τον **Σεπτέμβριο 2025.**

Δείτε το κείμενο της προκήρυξης [**ΕΔΩ**](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2025/03/Elliniki-Prokirixi-xeimerino-2025-2026-1.pdf).

Share

#### Related posts

16 Απριλίου, 2025

#### [Τμήμα Νομικής – Προκήρυξη Θέσεων Μεταπτυχιακών Προγραμμάτων για το Χειμερινό Εξάμηνο του Ακαδημαϊκού Έτους 2025/2026 – Εισδοχή Σεπτέμβριος 2025](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%bd%ce%bf%ce%bc%ce%b9%ce%ba%ce%ae%cf%82-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be%ce%b7-%ce%b8%ce%ad%cf%83%ce%b5%cf%89%ce%bd-%ce%bc%ce%b5%cf%84%ce%b1/)

---

[Διαβάστε περισσότερα](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%bd%ce%bf%ce%bc%ce%b9%ce%ba%ce%ae%cf%82-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be%ce%b7-%ce%b8%ce%ad%cf%83%ce%b5%cf%89%ce%bd-%ce%bc%ce%b5%cf%84%ce%b1/)

26 Μαρτίου, 2025

#### [ΠΑΡΑΤΑΣΗ ΠΡΟΘΕΣΜΙΑΣ ΥΠΟΒΟΛΗΣ ΑΙΤΗΣΕΩΝ ΓΙΑ ΤΟ ΧΕΙΜΕΡΙΝΟ ΕΞΑΜΗΝΟ 2025/2026](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/)

---

[Διαβάστε περισσότερα](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/)

6 Μαρτίου, 2025

#### [Τμήμα Βιολογικών Επιστημών – Προκήρυξη Θέσεων Μεταπτυχιακών Προγραμμάτων για το Χειμερινό Εξάμηνο του Ακαδημαϊκού Έτους 2025/2026 – Εισδοχή Σεπτέμβριος 2025](https://www.ucy.ac.cy/graduateschool/department-of-biological-sciences-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/)

---

[Διαβάστε περισσότερα](https://www.ucy.ac.cy/graduateschool/department-of-biological-sciences-postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/)

#### Επικοινωνία

***Γραφεία Σχολής Μεταπτυχιακών Σπουδών:***  
Πανεπιστημιούπολη  
Κτήριο Συμβουλίου-Συγκλήτου "Αναστάσιος Γ. Λεβέντης"  
Ισόγειο  
Λεωφόρος Πανεπιστημίου 1  
2109 Αγλαντζιά
  
  
  
***Διεύθυνση Αλληλογραφίας:***
Σχολή Μεταπτυχιακών Σπουδών  
Πανεπιστήμιο Κύπρου  
Τ.Θ.: 20537  
1678 Λευκωσία  
  
 : +357-22-894044  
 : [[email protected]](/cdn-cgi/l/email-protection)   
 :
[[email protected]](/cdn-cgi/l/email-protection)  
  
[ΧΡΗΣΙΜΕΣ ΠΛΗΡΟΦΟΡΙΕΣ ΓΙΑ ΦΟΙΤΗΤΕΣ/ΤΡΙΕΣ](https://www.ucy.ac.cy/graduateschool/wp-content/uploads/sites/45/2025/01/useful-information-for-students-gr.png)

#### Ακολουθήστε μας

#### Τελευταία Νέα

* [0

  ###### Τμήμα Νομικής – Προκήρυξη Θέσεων Μεταπτυχιακών Προγραμμάτων για το Χειμερινό Εξάμηνο του Ακαδημαϊκού Έτους 2025/2026 – Εισδοχή Σεπτέμβριος 2025

  16 Απριλίου, 2025](https://www.ucy.ac.cy/graduateschool/%cf%84%ce%bc%ce%ae%ce%bc%ce%b1-%ce%bd%ce%bf%ce%bc%ce%b9%ce%ba%ce%ae%cf%82-%cf%80%cf%81%ce%bf%ce%ba%ce%ae%cf%81%cf%85%ce%be%ce%b7-%ce%b8%ce%ad%cf%83%ce%b5%cf%89%ce%bd-%ce%bc%ce%b5%cf%84%ce%b1/)
* [0

  ###### ΠΑΡΑΤΑΣΗ ΠΡΟΘΕΣΜΙΑΣ ΥΠΟΒΟΛΗΣ ΑΙΤΗΣΕΩΝ ΓΙΑ ΤΟ ΧΕΙΜΕΡΙΝΟ ΕΞΑΜΗΝΟ 2025/2026

  26 Μαρτίου, 2025](https://www.ucy.ac.cy/graduateschool/%cf%80%ce%b1%cf%81%ce%b1%cf%84%ce%b1%cf%83%ce%b7-%cf%80%cf%81%ce%bf%ce%b8%ce%b5%cf%83%ce%bc%ce%b9%ce%b1%cf%83-%cf%85%cf%80%ce%bf%ce%b2%ce%bf%ce%bb%ce%b7%cf%83-%ce%b1%ce%b9%cf%84%ce%b7%cf%83%ce%b5/)

#### Εγγραφείτε εδώ !

Όνομα και Επίθετο

Ηλεκτρονικό Ταχυδρομείο

[Αποδοχή πολιτικής χρήσης των προσωπικών δεδομένων του Πανεπιστημίου Κύπρου](https://www.ucy.ac.cy/legislation/wp-content/uploads/KD-7.pdf)

#### Ημερολόγιο

Μάιος 2025

| Δ | Τ | Τ | Π | Π | Σ | Κ |
| --- | --- | --- | --- | --- | --- | --- |
|  | | | 1 | 2 | 3 | 4 |
| 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| 12 | 13 | 14 | 15 | 16 | 17 | 18 |
| 19 | 20 | 21 | 22 | 23 | 24 | 25 |
| 26 | 27 | 28 | 29 | 30 | 31 |  |

[« Απρ](https://www.ucy.ac.cy/graduateschool/2025/04/)

[©  Πανεπιστήμιο Κύπρου](https://www.ucy.ac.cy/el). Με επιφύλαξη παντός δικαιώματος, όλα τα δικαιώματα προστατεύονται.

* [![EN](https://www.ucy.ac.cy/graduateschool/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.png)](https://www.ucy.ac.cy/graduateschool/postgraduate-programme-places-for-the-fall-semester-of-the-academic-year-2025-2026-entry-september-2025/?lang=en)
* [![EL](https://www.ucy.ac.cy/graduateschool/wp-content/plugins/sitepress-multilingual-cms/res/flags/el.png)](https://www.ucy.ac.cy/graduateschool/%cf%80%cf%81%ce%bf%ce%ba%ce%b7%cf%81%cf%85%ce%be%ce%b7-%ce%b8%ce%b5%cf%83%ce%b5%cf%89%ce%bd-%ce%bc%ce%b5%cf%84%ce%b1%cf%80%cf%84%cf%85%cf%87%ce%b9%ce%b1%ce%ba%cf%89%ce%bd-%cf%80%cf%81%ce%bf%ce%b3-5/)